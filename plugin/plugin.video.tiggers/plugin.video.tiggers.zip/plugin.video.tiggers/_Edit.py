import xbmcaddon

MainBase = 'https://goo.gl/Te23RS'
addon = xbmcaddon.Addon('plugin.video.tiggers')