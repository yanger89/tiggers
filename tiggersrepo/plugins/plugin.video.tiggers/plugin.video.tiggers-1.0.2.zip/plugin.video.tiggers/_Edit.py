import xbmcaddon

MainBase = 'https://www.dropbox.com/s/ru6oei73m8lczso/home2.txt?dl=1'
addon = xbmcaddon.Addon('plugin.video.tiggers')